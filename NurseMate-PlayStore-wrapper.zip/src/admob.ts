import { AdMob } from '@capacitor-community/admob';

const TEST_BANNER = 'ca-app-pub-3940256099942544/9214589741';

async function startAds() {
  // The native AdMob SDK is only available inside the Android/iOS Capacitor app.
  if (!('Capacitor' in window)) return;

  try {
    await AdMob.start();

    // Use Google's test banner while developing.
    // Replace TEST_BANNER with your real banner ad unit before production.
    await AdMob.adCreate({
      adUnitId: TEST_BANNER,
      // @ts-ignore - supported by the plugin's mobile-ad options
      adSize: 'BANNER',
      // @ts-ignore
      position: 'bottom'
    });
  } catch (error) {
    console.warn('NurseMate AdMob initialization failed:', error);
  }
}

window.addEventListener('load', () => {
  void startAds();
});
